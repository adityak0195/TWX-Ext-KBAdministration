# DevOps related
* TWX Extension will be automatically installed
* For DEV/TEST environment latest Pre-Release is used
* For PROD latest Release is used
